[InternetShortcut]
URL=https://github.com/SEVAK1996/Contact-me/blob/main/binance_executor.py
